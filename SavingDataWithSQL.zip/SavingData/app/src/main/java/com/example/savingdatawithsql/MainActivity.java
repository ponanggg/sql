import android.app.AlertDialog.Builder;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

import com.example.savingdatawithsql.R;

public class MainActivity extends AppCompatActivity implements OnClickListener {
    EditText etStdntID, etStdntName, etStdntProg;
    Button btAdd, btDelete, btSearch, btView;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etStdntID = findViewById(R.id.etStdntID);
        etStdntName = findViewById(R.id.etStdntName);
        etStdntProg = findViewById(R.id.etStdntProg);

        btAdd = findViewById(R.id.btAdd);
        btDelete = findViewById(R.id.btDelete);
        btSearch = findViewById(R.id.btSearch);
        btView = findViewById(R.id.btView);

        btAdd.setOnClickListener(this);
        btDelete.setOnClickListener(this);
        btSearch.setOnClickListener(this);
        btView.setOnClickListener(this);

        db = openOrCreateDatabase("StudentDB", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS student(stdnt_id VARCHAR, stdnt_name VARCHAR, stdnt_prog VARCHAR);");
    }

    public void clearText() {
        etStdntID.setText("");
        etStdntName.setText("");
        etStdntProg.setText("");
        etStdntID.requestFocus();
    }

    public void showMessage(String title, String message) {
        Builder builder = new Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

    @Override
    public void onClick(View v) {
        if (v == btAdd) {
            if (etStdntID.getText().toString().trim().isEmpty() ||
                    etStdntName.getText().toString().trim().isEmpty() ||
                    etStdntProg.getText().toString().trim().isEmpty()) {
                showMessage("Error", "Please enter all values");
                return;
            }
            db.execSQL("INSERT INTO student VALUES('" + etStdntID.getText() + "','" + etStdntName.getText() + "','" + etStdntProg.getText() + "');");
            showMessage("Success", "Record added");
            clearText();
        }
        if (v == btDelete) {
            if (etStdntID.getText().toString().trim().isEmpty()) {
                showMessage("Error", "Please enter Student ID");
                return;
            }
            Cursor c = db.rawQuery("SELECT * FROM student WHERE stdnt_id='" + etStdntID.getText() + "'", null);
            if (c.moveToFirst()) {
                db.execSQL("DELETE FROM student WHERE stdnt_id='" + etStdntID.getText() + "'");
                showMessage("Success", "Record deleted");
            } else {
                showMessage("Error", "Invalid Student ID");
            }
            clearText();
        }
        if (v == btSearch) {
            if (etStdntID.getText().toString().trim().isEmpty()) {
                showMessage("Error", "Please enter Student ID");
                return;
            }
            Cursor c = db.rawQuery("SELECT * FROM student WHERE stdnt_id='" + etStdntID.getText() + "'", null);
            if (c.moveToFirst()) {
                etStdntName.setText(c.getString(1));
                etStdntProg.setText(c.getString(2));
            } else {
                showMessage("Error", "Invalid Student ID");
                clearText();
            }
        }
        if (v == btView) {
            Cursor c = db.rawQuery("SELECT * FROM student", null);
            if (c.getCount() == 0) {
                showMessage("Error", "No records found");
                return;
            }
            StringBuilder buffer = new StringBuilder();
            while (c.moveToNext()) {
                buffer.append("Student ID: ").append(c.getString(0)).append("\n");
                buffer.append("Student Name: ").append(c.getString(1)).append("\n");
                buffer.append("Student Program: ").append(c.getString(2)).append("\n\n");
            }
            showMessage("Student Details", buffer.toString());
        }
    }
}
